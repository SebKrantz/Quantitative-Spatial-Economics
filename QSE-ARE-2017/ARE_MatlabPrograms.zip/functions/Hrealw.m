
function [realwage] = Hrealw(fund,L,w,tradesh)

global alpha sigma tLL F;

% fund(:,1)=a; fund(:,2)=H; 
a=fund(:,1); H=fund(:,2); 

% domestic trade share;
dtradesh=diag(tradesh);

% real wage;
realwage=((L./(sigma.*F.*dtradesh)).^(alpha./(sigma-1))).*(a.^alpha).*((L./H).^(-(1-alpha)));
realwage=realwage./(alpha.*((sigma./(sigma-1)).^alpha).*(((1-alpha)./alpha).^(1-alpha)));
