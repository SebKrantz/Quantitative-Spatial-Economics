
function [r] = Hlandprice(fund,L,w)

global alpha sigma LL LLwest LLeast;

% fund(:,1)=a; fund(:,2)=H; 
a=fund(:,1); H=fund(:,2); 

r=((1-alpha)./alpha).*((w.*L)./H);